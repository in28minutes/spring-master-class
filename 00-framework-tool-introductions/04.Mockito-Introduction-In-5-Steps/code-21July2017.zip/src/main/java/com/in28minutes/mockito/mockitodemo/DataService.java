package com.in28minutes.mockito.mockitodemo;

public interface DataService {
	int[] retrieveAllData();
}